"""Plot captured public minute aggregates; this does not query or load a node."""
import datetime as dt
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np

root = Path(__file__).resolve().parent
load = lambda name: json.loads((root / name).read_text())
parse = lambda value: dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
start, end = parse("2026-09-08T05:08:00Z"), parse("2026-09-08T06:18:00Z")
canonical = [r for r in load("canonical-tps-60s.json") if start <= parse(r["timestamp"]) < end]
wait_requests = [r for r in load("requests-waits.json") if r["file"] == "external-wait-avg-60s.json"]
assert len(wait_requests) == 1
keys = {name: "t" + str(i + 1) for i, name in enumerate(wait_requests[0]["stats"])}
waits = {r["timestamp"]: r for r in load("external-wait-avg-60s.json")}
accepted = {r["timestamp"]: r for r in load("accepted-block-metrics-60s.json")}
xs = [parse(r["timestamp"]) for r in canonical]

plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, (top, bottom) = plt.subplots(2, 1, figsize=(11.5, 6.3), sharex=True)
fig.subplots_adjust(top=.87, bottom=.17, hspace=.16, left=.095, right=.98)
fig.suptitle("Server A: TPS plateaus while waiting for external work", x=.095, ha="left", fontsize=16)
fig.text(.095, .91, "8 September 2026 · public Session Stats · one-minute aggregates", color="#555555")
top.plot(xs, [r["wc"] / 1000 for r in canonical], color="#176b9e", linewidth=2)
top.axhline(50, linestyle="--", color="#777777", linewidth=.8)
top.set_ylabel("Canonical logical TPS\n(thousands)")
top.set_ylim(0, 82)
for panel in (top, bottom):
    panel.grid(axis="y", color="#dddddd", linewidth=.6)
    panel.set_xlim(start, end)

for suffix, label, color in [
    ("first_work", "First work", "#8a4eb0"),
    ("fragment_refill", "Fragment refill", "#cc7928"),
    ("post_commit_idle", "Idle after commit", "#368557"),
]:
    key = keys["BLOCK_collate_work_time_real_external_wait_native_" + suffix + "_s"]
    ys = [waits[r["timestamp"]][key] * 1000
          if r["wc"] >= 40000 and r["timestamp"] in waits and accepted.get(r["timestamp"], {}).get("t1", 0) > 0
          else np.nan for r in canonical]
    bottom.plot(xs, ys, color=color, label=label, linewidth=1.7)
bottom.set_ylabel("Mean wait per accepted\nblock (milliseconds)")
bottom.set_ylim(bottom=0)
bottom.legend(loc="upper left", ncol=3, frameon=False, fontsize=9)
bottom.xaxis.set_major_locator(mdates.MinuteLocator(byminute=range(0, 60, 10)))
bottom.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M", tz=dt.timezone.utc))
bottom.set_xlabel("UTC")
fig.text(.095, .045, "Wait panel shows buckets at or above 40k TPS; lower-load startup/drain buckets are omitted.\n"
         "Connection counts cannot be assigned: the dashboard returned no test-run labels.\n"
         "These observations do not establish offered load, completed proof/drain checks, or maximum capacity.",
         fontsize=9, color="#555555")
fig.savefig(root / "native-chart-scaling-20260908.png", dpi=160)
fig.savefig(root / "native-chart-scaling-20260908.svg")
